USE ap;
SELECT vendor_name, invoice_number, invoice_date, 
 DATE_FORMAT(invoice_date, '% W, %M %D, %Y') AS inv_date_formatted, 
 MONTHNAME(invoice_date) AS inv_month, 
  EXTRACT(YEAR FROM invoice_date) AS inv_year, 
 DATE_ADD(invoice_date, INTERVAL 2 MONTH) AS inv_date_plus2,
 DATEDIFF('2016-01-01', invoice_date) AS inv_date_diff
 FROM invoices JOIN vendors 
 WHERE invoice_date >= ('2014-06-00')