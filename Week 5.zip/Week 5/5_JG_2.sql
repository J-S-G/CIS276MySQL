USE ap; 
SELECT vendor_name, SUBSTRING(vendor_phone, 7, 8) AS no_ac_phone, 
RIGHT(vendor_name,LENGTH(vendor_name)-LOCATE(' ',vendor_name)) AS v_name_wo_first_name
FROM vendors
WHERE LOCATE('D',vendor_name)
ORDER BY vendor_name