USE ap;
SELECT vendor_name, invoice_number, invoice_total, 
CASE invoice_total 
WHEN invoice_total > 20000 THEN 'Largest Invoices'
WHEN invoice_total = 5001 >= 20000 THEN 'Large Invoice'
WHEN invoice_total BETWEEN 500 AND 5000 THEN 'Medium Invoice'
WHEN invoice_total < 500 THEN 'Small Invoice' 
END AS invoice_type 
FROM vendors v LEFT JOIN invoices i
ON v.vendor_id = i.vendor_id
