USE ap;
SELECT vendor_name, vendor_state, 
IF(vendor_state = 'CA', 'California vendor', 'Non California vendor') AS 'CA vendor?', 
invoice_number, invoice_date, invoice_total,(invoice_number-invoice_date-invoice_total) AS bal_due,
IF(invoice_number-invoice_date-invoice_total = 0, 'PAID', 'UNPAID') AS pay_status
 FROM vendors v LEFT JOIN invoices i
 ON v.vendor_id = i.vendor_id 
 
 
 
 


