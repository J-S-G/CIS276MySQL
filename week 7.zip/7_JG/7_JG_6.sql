USE donations;
SELECT donor_first, donor_last, donation_desc, donation_value, 
(donation_value - donation_value * .10) AS actual_value
FROM donor JOIN donation 
WHERE pickup_req = 'CASH'