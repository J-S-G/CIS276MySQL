USE donations;
SELECT donor_first, donor_last, donor_phone
FROM donor JOIN donation ON donor.donor_id = donation.donor_id 
WHERE donation_value = 0
