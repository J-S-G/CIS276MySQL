CREATE DATABASE IF NOT EXISTS donations;
USE donations;
CREATE TABLE donor
(
	donor_id 		INT NOT NULL 		AUTO_INCREMENT,
    donor_first 	VARCHAR(20) 		NOT NULL,
    donor_last 		VARCHAR(25) 		NOT NULL,
    donor_address 	VARCHAR(40) 		NOT NULL,
    donor_city 		VARCHAR(20)			NOT NULL, 
    donor_zip 		VARCHAR(14)			NOT NULL,
    CONSTRAINT 		donor_id 		PRIMARY KEY (donor_id) 
);
CREATE TABLE donation
(
	donation_id 		INT 				NOT NULL AUTO_INCREMENT,
    donation_value 		DECIMAL (9,2) 		NOT NULL,
    donation_desc 		VARCHAR (100) 		NOT NULL, 
    donation_date 		DATE 		  		NOT NULL,
    donor_id 			INT			  		NOT NULL,
    agency_id 			INT			  		NOT NULL,
    CONSTRAINT donation_id PRIMARY KEY (donation_id),
    CONSTRAINT donor_id
    FOREIGN KEY (donor_id) REFERENCES donor(donor_id),
    CONSTRAINT donation_id
    FOREIGN KEY (agency_id) REFERENCES agency(agency_id)
);
CREATE TABLE agency
(
	agency_id 					INT 			NOT NULL AUTO_INCREMENT,
    agency_name 				VARCHAR(50) 	NOT NULL,
    contact_first 				VARCHAR(20) 	NOT NULL, 
    contact_last 				VARCHAR(25) 	NOT NULL,
    contact_phone 				VARCHAR(15) 	NOT NULL, 
    CONSTRAINT agency_id 		PRIMARY KEY (agency_id)
);	
