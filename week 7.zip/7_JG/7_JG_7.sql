USE donations;
SELECT donor_first, donor_last, SUM(donation_value) AS total_donations,
MAX(donation_value) AS largest_donation, 
AVG(donation_value) AS avg_donation 
FROM donor JOIN donation ON donor.donor_id = donation.donor_id 
GROUP BY donor_first, donor_last WITH ROLLUP 
 