USE donations;
SELECT donor_first, donor_last, donation_desc, donation_value,
donation_date, agency_name 
FROM donor JOIN donation 
ON donor.donor_id = donation.donor_id 
JOIN agency ON donation.donor_id = donation.agency_id 
WHERE donation_desc = 'CASH'
ORDER BY donor_last ASC