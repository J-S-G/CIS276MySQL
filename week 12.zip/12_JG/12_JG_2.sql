/* Hey Adam, I created a new username for you as requested. db_user account has been updated to global privileges.
*/
RENAME USER db_champ TO db_user; 
GRANT ALL 
ON *.*
TO db_user