CREATE USER IF NOT EXISTS ap_invoice_clerk;
SET PASSWORD FOR ap_selector = 'password';
/* //Grant select means the users only has permission to make select statements followed by the specific tables within a database
TO that user*/
GRANT SELECT ON ap.vendors
TO ap_invoice_clerk;

GRANT SELECT, UPDATE, INSERT 
ON ap.invoices
TO ap_invoice_clerk;

GRANT SELECT, UPDATE, INSERT 
ON ap.invoice_line_items
TO ap_invoice_clerk;
