drop user db_user, ap_selector, ap_invoice_clerk; 

