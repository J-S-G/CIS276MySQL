/* Hi Adam, you currently have access to the ap database */
CREATE USER db_champ IDENTIFIED BY '1234';
GRANT SELECT, INSERT, UPDATE 
ON ap.*
TO db_champ

