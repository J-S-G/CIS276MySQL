/*  User: ap_selector has access to only the select statements within the ap database.
Password: j0seph  
*/
CREATE USER ap_selector;
SET PASSWORD FOR ap_selector = 'j0seph';
GRANT SELECT 
ON ap.*
TO ap_selector;


