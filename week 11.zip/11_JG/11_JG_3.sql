USE ap;
CREATE TABLE IF NOT EXISTS invoice_audit 
(
	vendor_id 			INT 			NOT NULL,
    invoice_number		VARCHAR(50)		NOT NULL,
    invoice_total 		DECIMAL(9,2)	NOT NULL,
    action_type			VARCHAR(50)		NOT NULL,
    action_date			DATETIME		NOT NULL
);