SET GLOBAL event_scheduler = OFF; 
USE ap; 
DROP EVENT IF EXISTS add_audit_rows;
DELIMITER //
CREATE EVENT add_audit_rows 
	ON SCHEDULE EVERY 60 SECOND 
DO BEGIN
	INSERT INTO invoice_audit 
VALUES(999, 'TEST Invoice', 0.00, 'Test Insert', NOW());
END//
/*//Every minute the event will add a row into the invoice_audit table
//to stop the process change on to off in the GLOBAL event_scheduler = (ON/OFF)
//Super cool automated task!*/
USE ap;
SELECT * FROM invoice_audit; 