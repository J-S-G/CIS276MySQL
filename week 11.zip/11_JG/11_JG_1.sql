USE ap;
DROP TRIGGER IF EXISTS vend_before_update;
DELIMITER //
CREATE TRIGGER vend_before_update
	BEFORE UPDATE ON vendors_copy
	FOR EACH ROW 
BEGIN
	SET NEW.vendor_address2 = UPPER(NEW.vendor_address2);
END//

USE ap; 
UPDATE vendors_copy 
SET vendor_address2 = 'na'
WHERE vendor_address2 IS NULL;  

SELECT vendor_id, vendor_name, vendor_address1, vendor_address2 FROM vendors_copy;