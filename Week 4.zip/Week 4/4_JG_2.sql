USE ap;
INSERT INTO invoices_copy 
(invoice_id, vendor_id, invoice_number, invoice_date,
payment_total, credit_total, terms_id, invoice_due_date, payment_date )
VALUES
(DEFAULT, 115, 125, 'P-029324', 2014-08-03, 345.60, 0, 0, 1, 2014-08-13, NULL ),
(DEFAULT, 116, 126, '546789', 2014-08-03, 1139.45, 0, 0, 3, 2014-09-03, NULL ),
(DEFAULT, 117, 124, '129-45777', 2014-08-04, 250.99, 0, 0, 2, 2014-08-24, NULL );

