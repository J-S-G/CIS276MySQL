USE ap;
DELETE FROM vendors 
 WHERE vendor_id NOT IN (SELECT vendor_id FROM invoices_copy)