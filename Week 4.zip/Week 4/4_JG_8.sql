USE ap;
SELECT vendor_name, invoice_number, invoice_date, invoice_total
FROM v.vendors JOIN i.invoices 
WHERE v.invoice_date <(SELECT MAX(invoice_date)
						FROM invoices AS i.invoice_date
                        WHERE v.vendors_date = max_date)
ORDER BY vendor_name DESC
