USE ap;
(SELECT vendor_id, invoice_number, invoice_date, invoice_total, 
invoice_total - payment_total - credit_total AS balance_due
FROM vendors_copy JOIN i.invoices
ON v.vendor_id = i.vendors_id
WHERE vendor_id IN (110, 121, 122, 123))
ORDER BY v.vendor_id, balance_due, invoice_total
