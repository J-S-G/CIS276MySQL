USE ap;
SELECT vendor_name, max_total 
/*subquery to display values based on vendor_id column (using in)*/