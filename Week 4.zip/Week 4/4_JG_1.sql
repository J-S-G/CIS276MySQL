USE ap;
INSERT INTO vendors_copy
VALUES (DEFAULT, 1, 'Waste Management', 'Phoenix', AZ, 
'(602)279-5641', 'Reeves', 2 ),
(DEFAULT, 2, 'Zip Printing', 'Bakersfield', CA, 
'(559)871-6564', 'Smith', 1),
(DEFAULT, 3, 'ACM Development', 'Seattle', WA,
'(206)541-9112', 'Ayers', 4);

INSERT INTO vendors_copy
VALUES (DEFAULT, 124, '23 E. Washington', 'NULL', '85001', 'Bryant', 521),
(DEFAULT, 125, '412 N. Elm', 'NULL', '92659', 'Kathy', 551),
(DEFAULT, 124, '8974 S. 17^th Ave', 'Suite 200', '98102', 'Ernesto', 167);
SELECT * FROM vendors_copy


