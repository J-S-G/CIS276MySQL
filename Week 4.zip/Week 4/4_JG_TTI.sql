USE ap;
DROP TABLE IF EXISTS vendors_copy;
CREATE TABLE vendors_copy AS
SELECT*
FROM vendors


