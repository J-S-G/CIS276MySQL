USE ap;
SELECT vendor_id, invoice_number, invoice_date, invoice_total
FROM v.vendors JOIN i.invoices
ON v.vendor_id = i.vendor_id
WHERE v.vendor_state = 'CA'
ORDER BY v.vendor_id, invoice_date 