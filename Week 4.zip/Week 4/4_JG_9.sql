USE ap;
SELECT vendor_name, MAX(avg_bal) AS max_bal_due
FROM 
(SELECT vendor_name, 
	AVG(invoice_total - payment_total - credit_total) AS avg_bal
    FROM vendors v JOIN invoices i 
     ON v.vendors_id = i.vendor_id
	GROUP BY vendor_name) t
    GROUP BY vendor_name
ORDER BY max_bal_due DESC
LIMIT 3