Use ap;
SELECT vendor_name, vendor_city, vendor_state,
invoice_number, invoice_date, invoice_total 
FROM vendors v JOIN invoices i
ON v.vendor_id = i.Vendor_id
WHERE invoice_date BETWEEN '2014-06-01' AND '2014-06-30' AND (invoice_total > 500)
ORDER BY vendor_name ASC, invoice_total ASC