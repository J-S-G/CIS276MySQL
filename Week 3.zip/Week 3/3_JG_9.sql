USE ap;
SELECT vendor_city, vendor_state, SUM(invoice_total) AS invoice_totals
FROM vendors JOIN invoices
WHERE vendor_state IN ('CA','TN')
GROUP BY vendor_state, vendor_city WITh ROLLUP 

