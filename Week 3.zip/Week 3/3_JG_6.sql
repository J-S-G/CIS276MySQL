USE ap;
SELECT vendor_state, invoice_total AS state_totals, COUNT(*) AS state_inv_count,
AVG (invoice_total + payment_total + credits_total) AS state_avg, 
FROM invoices, vendors 
UNION
SELECT vendor_state, invoice_total AS state_totals, COUNT(*) AS state_inv_count,
MAX(invoice_total + payment_total + credits_total) AS state_max,
from invoices, vendors
UNION
SELECT vendor_state, invoice_total AS state_totals, COUNT(*) AS state_inv_count,
MIN(invoice_total + payment_total + credits_total) AS state_min
FROM invoices, vendors
ORDER BY COUNT(*) AS state_inv_count ASC 

