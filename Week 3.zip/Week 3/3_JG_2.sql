USE ap;
SELECT vendor_name, invoice_date, invoice_total, line_item_amount, 
account_description, vendor_state
FROM vendors v, invoices i, invoice_line_items il, general_ledger_accounts g
WHERE (v.vendor_id = i.vendor_id) AND
(il.invoice_id = i.invoice_id) AND
(g.account_number = il.account_number) AND
vendor_state IN ('AZ','CA','NV')
ORDER BY vendor_name ASC