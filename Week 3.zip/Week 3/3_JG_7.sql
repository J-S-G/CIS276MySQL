USE ap;
SELECT vendor_id, COUNT(*) AS invoice_gt, 
AVG(invoice_total) AS invoice_avg,
invoice_number AS invoice_qty
FROM invoices i JOIN vendors v
ON v.vendors_id = i.vendors_id
WHERE invoice_total > 300
GROUP BY vendor_id
ORDER BY invoice_avg DESC

