USE ap;
SELECT vendor_name, SUM(invoice_total - payment_total - credit_total) 
AS total_inv_amount, COUNT(*) AS inv_count, 
FROM vendors JOIN invoices 
WHERE invoice_total > 1
AND vendor_state = 'CA'
ORDER BY invoice_total