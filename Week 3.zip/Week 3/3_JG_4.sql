USE ap;
SELECT vendor_name, CONCAT (vendor_city, ', ' ,vendor_state) AS location, 
invoice_number, invoice_total 
FROM vendors v LEFT JOIN invoices i
ON v.vendor_id = i.invoice_id 
GROUP BY vendor_name
ORDER BY invoice_number DESC
