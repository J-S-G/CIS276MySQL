USE ap;
SELECT vendor_name, vendor_zip_code, 'Fresno area' AS vendor_state , vendor_state AS zone_location
FROM vendors
WHERE vendor_city = 'Fresno' 
UNION
SELECT vendor_name, vendor_zip_code,'LA area' AS vendor_state, vendor_state AS zone_location
FROM vendors
WHERE vendor_city IN ('Los Angeles', 'Anaheim', 'Inglewood', 'Pasadena') 
UNION
SELECT vendor_name, vendor_zip_code,'CA regional' AS vendor_state, vendor_state AS zone_location
FROM vendors
WHERE vendor_city <> 'Fresno''Los Angeles' 'Anaheim' 'Inglewood' 'Pasadena' 
ORDER BY zone_location AND vendor_name DESC