USE ap;
SELECT DISTINCT vendor_name, vendor_city, invoice_number, 
invoice_total, invoice_total - payment_total - credit_total AS balance_due, line_item_amount 
FROM vendors v JOIN invoices i 
ON v.vendor_id = i.vendor_id
JOIN invoice_line_items il
ON i.invoice_id = il.invoice_id
WHERE invoice_total BETWEEN 300 AND 800 AND
vendor_city = 'Fresno' AND invoice_total - payment_total - credit_total = 0
ORDER BY invoice_total DESC
 
