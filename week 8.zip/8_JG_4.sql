USE cf;
CREATE OR REPLACE VIEW service_billing AS
SELECT DISTINCT p.service_id, fleet_make, fleet_model, p.service_date, p.service_desc, 
CAST(tot_parts_price AS DECIMAL (9,2)) AS tot_parts_price, CAST(labor_price AS DECIMAL(9,2)) AS labor_price,
CAST(tot_parts_price AS DECIMAL (9,2)) + CAST(labor_price AS DECIMAL(9,2)) AS tot_billing 
FROM labor_pricing l JOIN parts_pricing p
ON l.service_id = p.service_id 
JOIN service_subtotal s ON p.service_id = s.service_id;

SELECT * FROM service_billing