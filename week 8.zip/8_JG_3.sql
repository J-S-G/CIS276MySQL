USE cf;
CREATE OR REPLACE VIEW service_subtotal AS
SELECT p.service_id, p.service_date, p.service_desc, SUM(tot_parts_price)
AS tot_parts_cost
FROM labor_pricing l JOIN parts_pricing p
ON l.service_id = p.service_id
GROUP BY p.service_id, p.service_date, p.service_desc;
SELECT * FROM service_subtotal