USE ap;
DROP PROCEDURE IF EXISTS ch13_2;
DELIMITER //
CREATE PROCEDURE ch13_2()
BEGIN
DECLARE sum_inv_total DECIMAL(9,2); 
DECLARE inv_count INT;
DECLARE vend_id INT;

SET vend_id = 123;

SELECT CONCAT(COUNT(*), SUM(sum_inv_total) ) AS TotalInvAmt, CONCAT(COUNT(*), SUM(inv_count) ) AS InvoiceCount
FROM invoices 
WHERE vendor_id = vend_id;
END//