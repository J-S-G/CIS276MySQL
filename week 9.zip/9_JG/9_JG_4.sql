USE ap;
DROP PROCEDURE IF EXISTS ch13_4;
DELIMITER //
CREATE PROCEDURE ch13_4()
BEGIN
DECLARE tot_due DECIMAL(9,2);

SELECT SUM(invoice_total - credit_total - payment_total) AS tot_due
FROM invoices 
INTO tot_due;

IF tot_due > 50000 THEN 
	SELECT 'High invoice balance detected' AS high_balance; 
ELSEIF tot_due BETWEEN 50000 AND 30000 THEN 
	SELECT 'Substantial invoice balance detected' AS substantial_balance; 
ELSEIF tot_due BETWEEN 29999 AND 20000 THEN 
	SELECT 'Manageable invoice balance detected' AS manageable_balance;
ELSE 
	SELECT 'Low invoice balance detected' AS low_balance;
END IF;
END//