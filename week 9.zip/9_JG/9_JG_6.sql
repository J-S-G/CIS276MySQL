USE ap;
DROP PROCEDURE IF EXISTS ch13_6;
DELIMITER //
CREATE PROCEDURE ch13_6()
BEGIN
DECLARE lc, x, y INT;
DECLARE s VARCHAR(600) DEFAULT '';
SET x = 128;
SET y = 8;
SET lc = 1;

WHILE lc < 9 DO
SET s = CONCAT(s, CONCAT('Position ', y, ' = '), x, ' | ');
SET x = x / 2;
SET y = y -1; 
SET lc = lc +1;
END WHILE;
SELECT s AS 8_bit_binary_digit;
END//

CALL ch13_6;