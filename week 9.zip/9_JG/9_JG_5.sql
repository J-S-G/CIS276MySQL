USE ap;
DROP PROCEDURE IF EXISTS ch13_2;
DELIMITER //
CREATE PROCEDURE ch13_2()
BEGIN
DECLARE v_state VARCHAR(2);
DECLARE v_city VARCHAR(30);
DECLARE inv_id INT;

SET inv_id = 15;
SELECT inv_id, vendor_id 
FROM vendors
WHERE inv_id = vendor_id
INTO v_state, v_city;
CASE 
WHEN 1 THEN
IF 
		v_state = 'AZ' THEN 
		SELECT 'Arizona vendor' AS message;
ELSEIF
		v_state = 'CA' THEN SELECT 'California Vendor' AS message;
ELSE
		SELECT 'National Vendor' AS message; 
END IF;

WHEN 2 THEN
IF
		v_city = 'FRESNO' THEN 
        SELECT 'Fresno California Vendor' AS message;
ELSE
		SELECT 'LA Metro California vendor' AS message;
END IF;
END CASE;
END//